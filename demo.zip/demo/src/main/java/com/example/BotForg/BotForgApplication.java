package com.example.BotForg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BotForgApplication {

	public static void main(String[] args) {
		SpringApplication.run(BotForgApplication.class, args);
	}

}
