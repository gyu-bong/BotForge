package com.example.BotForg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BotForgApplicationTests {

	@Test
	void contextLoads() {
	}

}
